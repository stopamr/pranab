"use client"

import { useState } from "react"
import { Play, Info, MapPin, Mail, Phone, Globe, Users, FileText, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function DrChatterjeeCV() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)
  const [selectedSection, setSelectedSection] = useState<string | null>(null)

  const professionalExperience = [
    {
      id: "jhu",
      title: "PhD Candidate, Graduate Research Assistant and Teaching Assistant",
      company: "Johns Hopkins University",
      department: "Department of International Health, Johns Hopkins Bloomberg School of Public Health",
      location: "Baltimore, USA",
      period: "08/2020 – Present",
      description:
        "Conducting doctoral research in Global Disease Epidemiology and Control while serving as graduate research and teaching assistant.",
      image: "/placeholder.svg?height=300&width=400&text=Johns+Hopkins+University",
      highlights: [
        "PhD in Global Disease Epidemiology",
        "Teaching Assistant for multiple courses",
        "Research on antimicrobial resistance",
      ],
    },
    {
      id: "icmr-tghprc",
      title: "Public Health Scientist",
      company: "Indian Council of Medical Research",
      department:
        "Translational Global Health Policy Research Cell (TGHPRC), Department of Health Research, Ministry of Health and Family Welfare, Government of India",
      location: "New Delhi, India",
      period: "11/2019 – 07/2020",
      description:
        "Managed the TGHPRC, which evolved to become the secretariat for the National Task Force on COVID-19, India's apex research and policy making body during the pandemic.",
      image: "/placeholder.svg?height=300&width=400&text=COVID-19+Task+Force",
      highlights: [
        "COVID-19 National Task Force secretariat",
        "Policy research and evidence synthesis",
        "High-level meeting coordination",
      ],
    },
    {
      id: "icmr-niced",
      title: "Scientist",
      company: "Indian Council of Medical Research (ICMR)",
      department: "Division of Epidemiology, National Institute of Cholera and Enteric Diseases",
      location: "Kolkata, India",
      period: "01/2017 – 10/2019",
      description:
        "Co-led epidemiological studies on infectious diseases, particularly cholera, typhoid, and rotavirus. Conducted clinical trials and vaccine effectiveness studies.",
      image: "/placeholder.svg?height=300&width=400&text=Cholera+Research",
      highlights: [
        "6-arm clinical trial on rotavirus vaccine",
        "Oral Cholera Vaccine advocacy",
        "Multiple grant leadership",
      ],
    },
    {
      id: "phfi",
      title: "Senior Research Associate",
      company: "Public Health Foundation of India",
      department: "Public Health Foundation of India",
      location: "Delhi, India",
      period: "07/2015 – 01/2017",
      description:
        "Managed research projects focused on zoonotic diseases and antimicrobial resistance using One Health approach. Led multi-disciplinary teams and international collaborations.",
      image: "/placeholder.svg?height=300&width=400&text=One+Health+Research",
      highlights: ["One Health approach research", "Antimicrobial resistance studies", "International collaborations"],
    },
  ]

  const researchGrants = [
    {
      id: "placid",
      title: "PLACID Trial",
      subtitle: "Convalescent Plasma for COVID-19",
      period: "April - October 2020",
      funding: "₹10,000,000 (~$125,000)",
      agency: "Indian Council of Medical Research",
      role: "Co-Investigator",
      description:
        "Phase II, Open Label, Randomized Controlled Trial to Assess the Safety and Efficacy of Convalescent Plasma to Limit COVID-19 Associated Complications",
      image: "/placeholder.svg?height=400&width=600&text=PLACID+Trial",
      status: "Completed",
    },
    {
      id: "hcq-study",
      title: "HCQ Prophylaxis Study",
      subtitle: "Healthcare Workers COVID-19 Protection",
      period: "May - June 2020",
      funding: "Intramural funding",
      agency: "Indian Council of Medical Research",
      role: "Co-Principal Investigator",
      description:
        "Association of Hydroxychloroquine Prophylaxis with SARS-CoV-2 Infection in Healthcare Workers: A Case Control Study",
      image: "/placeholder.svg?height=400&width=600&text=HCQ+Study",
      status: "Completed",
    },
    {
      id: "tcv-evaluation",
      title: "TCV Evaluation Program",
      subtitle: "Typhoid Conjugate Vaccine Impact",
      period: "May 2018 - October 2019",
      funding: "₹2,100,000 (~$31,000)",
      agency: "WHO India",
      role: "Co-Investigator",
      description: "Evaluation of a Typhoid Conjugate Vaccine (TCV) Introduction Program in Navi Mumbai, India",
      image: "/placeholder.svg?height=400&width=600&text=TCV+Program",
      status: "Ongoing",
    },
    {
      id: "rvics",
      title: "RVICS Trial",
      subtitle: "Rotavirus Vaccine Interchangeability",
      period: "May 2018 - May 2021",
      funding: "₹57,600,000 (~$850,000)",
      agency: "Ministry of Health and Family Welfare, Government of India",
      role: "Co-Investigator",
      description:
        "Immunogenicity and Safety of Rotavac® and Rotasiil® Administered in an Interchangeable Dosing Schedule among Healthy Indian Infants",
      image: "/placeholder.svg?height=400&width=600&text=RVICS+Trial",
      status: "Completed",
    },
    {
      id: "nssefi",
      title: "NSSEFI Study",
      subtitle: "National Surveillance System for Enteric Fever",
      period: "January 2017 - May 2020",
      funding: "₹77,800,000 (~$1,132,768)",
      agency: "Bill and Melinda Gates Foundation via CMC Vellore",
      role: "Co-Investigator",
      description: "National Surveillance System for Enteric Fever in India to estimate the burden of enteric fever",
      image: "/placeholder.svg?height=400&width=600&text=NSSEFI+Study",
      status: "Completed",
    },
    {
      id: "sanipath",
      title: "SaniPath Typhoid Study",
      subtitle: "Environmental Transmission Assessment",
      period: "May 2018 - October 2019",
      funding: "₹28,800,000 (~$450,000)",
      agency: "Bill and Melinda Gates Foundation via Emory University",
      role: "Co-Investigator",
      description: "Assessment of Exposure to Typhoid Fever in Urban Slums using SaniPath Exposure Assessment approach",
      image: "/placeholder.svg?height=400&width=600&text=SaniPath+Study",
      status: "Completed",
    },
  ]

  const peerReviewedArticles = [
    {
      id: "cholera-risk-2024",
      title: "Analysis of Cholera Risk in India: Insights from 2017–18 Serosurvey Data",
      journal: "PLOS Neglected Tropical Diseases",
      year: "2024",
      authors: "Kanungo S, Nandy RK, Talukdar R, Murhekar M, Azman AS, Hegde ST, Chatterjee P, et al.",
      doi: "10.1371/journal.pntd.0012450",
      image: "/placeholder.svg?height=200&width=300&text=Cholera+Risk+Analysis",
      impact: "High Impact",
    },
    {
      id: "bhopal-covid-2024",
      title: "COVID-19 mortality in 1984 Bhopal gas tragedy survivors",
      journal: "Transactions of The Royal Society of Tropical Medicine and Hygiene",
      year: "2024",
      authors: "Dhingra R, Sarangi S, Chatterjee P, Gun A, Sarkar S",
      doi: "10.1093/trstmh/trae010",
      image: "/placeholder.svg?height=200&width=300&text=Bhopal+COVID+Study",
      impact: "High Impact",
    },
    {
      id: "ungrading-2023",
      title: "Exploring the implications of implementing ungrading in two graduate-level global health courses",
      journal: "Pedagogy in Health Promotion",
      year: "2023",
      authors: "Kalbarczyk A, Miller E, Majidulla A, Tarazona-Meza C, Chatterjee P, Sauer M, Closser S",
      doi: "10.1177/23733799231169204",
      image: "/placeholder.svg?height=200&width=300&text=Ungrading+Study",
      impact: "Educational Research",
    },
    {
      id: "typhoid-burden-2023",
      title: "Burden of Typhoid and Paratyphoid Fever in India",
      journal: "New England Journal of Medicine",
      year: "2023",
      authors: "John J, Bavdekar A, Rongsen-Chandola T, Dutta S, Gupta M, Kanungo S, ..., Chatterjee P, ..., Kang G",
      doi: "10.1056/NEJMoa2209449",
      image: "/placeholder.svg?height=200&width=300&text=NEJM+Typhoid",
      impact: "Very High Impact",
    },
    {
      id: "antioppressive-teaching-2023",
      title: "Using antioppressive teaching principles to transform a graduate global health course",
      journal: "BMJ Global Health",
      year: "2023",
      authors: "Kalbarczyk A, Aqil A, Sauer M, Chatterjee P, Jacques KA, Mooney G, Labrique A, Lee K",
      doi: "10.1136/bmjgh-2022-011587",
      image: "/placeholder.svg?height=200&width=300&text=Teaching+Transformation",
      impact: "Educational Research",
    },
  ]

  const bookChapters = [
    {
      id: "cholera-maintenance",
      title: "Oral Maintenance Therapy for Cholera in Adults",
      book: "50 Studies Every Global Health Provider Should Know",
      publisher: "Oxford University Press",
      year: "2024",
      editors: "Walker A, Agarwal A, Jain Y, and Series edited by Hochman ME",
      image: "/placeholder.svg?height=200&width=300&text=Oxford+Chapter",
      type: "Book Chapter",
    },
    {
      id: "mixed-methods-case",
      title:
        "Using Mixed Methods Approaches for Case–Control Studies of Complex Transmission Pathways of Enteric Fever",
      book: "SAGE Research Methods Cases",
      publisher: "SAGE Publications",
      year: "2020",
      authors: "Chatterjee P, Biswas T, Seth B",
      doi: "10.4135/9781529740806",
      image: "/placeholder.svg?height=200&width=300&text=SAGE+Methods",
      type: "Methods Case Study",
    },
    {
      id: "health-systems-research",
      title: "Health Systems Research",
      book: "IAPSM's Textbook of Community Medicine",
      publisher: "Jaypee Brothers Medical Publications",
      year: "2019",
      authors: "Chatterjee P, Seth B, Chauhan AS",
      image: "/placeholder.svg?height=200&width=300&text=Health+Systems",
      type: "Textbook Chapter",
    },
  ]

  const professionalActivities = [
    {
      id: "memberships",
      title: "Professional Memberships",
      items: [
        "Associate Member, Association of Cricket Statisticians and Historians, England (2024)",
        "Full Member, Sigma Xi, the Scientific Research Honor Society (2023)",
        "Member, American Public Health Association, USA (2022)",
        "Member, American Society of Tropical Medicine and Hygiene, USA (2022)",
        "Life Member, Epidemiology Foundation of India (2017)",
        "Life Member, Indian Association of Preventive and Social Medicine, India (2015)",
        "Life Member, Indian Public Health Association, India (2015)",
      ],
      image: "/placeholder.svg?height=200&width=300&text=Professional+Memberships",
      icon: Users,
    },
    {
      id: "editorial",
      title: "Editorial and Peer Review Activities",
      items: [
        "Associate Editor, Transactions of the Royal Society of Tropical Medicine and Hygiene (2019 – Present)",
        "Editorial Board, The Permanente Journal (2017 – 2019)",
        "Peer Reviewer: BMJ, BMJ Global Health, PLOS Global Public Health, The Journal of Infectious Diseases",
        "Peer Reviewer: Transactions of the Royal Society of Tropical Medicine and Hygiene",
        "Peer Reviewer: Global Health Action, Indian Journal of Medical Research, PLOS Medicine",
      ],
      image: "/placeholder.svg?height=200&width=300&text=Editorial+Activities",
      icon: FileText,
    },
  ]

  const honorsAwards = [
    {
      id: "bsph-excellence-2023",
      title: "Award for Excellence in International Public Health Practice",
      organization: "Johns Hopkins Bloomberg School of Public Health",
      year: "2023",
      description: "Recognized for outstanding contributions to international public health practice",
      image: "/placeholder.svg?height=200&width=300&text=BSPH+Excellence+Award",
      type: "Academic Excellence",
    },
    {
      id: "pulitzer-fellowship-2022",
      title: "Pulitzer Center Fellowship",
      organization: "Pulitzer Center",
      year: "2022",
      description:
        "Fellowship for Public Health reporting covering the continuing struggles of Bhopal Gas Tragedy survivors during COVID-19",
      image: "/placeholder.svg?height=200&width=300&text=Pulitzer+Fellowship",
      type: "Journalism Fellowship",
    },
    {
      id: "ghosh-mchi-2020",
      title: "Ghosh-MCHI Scholarship",
      organization: "Johns Hopkins Bloomberg School of Public Health",
      year: "2020",
      description: "Scholarship from the Department of International Health to support PhD tuition",
      image: "/placeholder.svg?height=200&width=300&text=PhD+Scholarship",
      type: "Academic Scholarship",
    },
    {
      id: "fellow-rsph-2017",
      title: "Fellow of the Royal Society of Public Health",
      organization: "Royal Society of Public Health, UK",
      year: "2017",
      description: "Fellowship recognition for contributions to public health",
      image: "/placeholder.svg?height=200&width=300&text=RSPH+Fellowship",
      type: "Professional Honor",
    },
    {
      id: "kusum-pandit-2015",
      title: "Kusum Pandit Award",
      organization: "University College of Medical Sciences, New Delhi",
      year: "2015",
      description: "Award for the best MD Thesis",
      image: "/placeholder.svg?height=200&width=300&text=Best+MD+Thesis",
      type: "Academic Excellence",
    },
  ]

  const teachingActivities = [
    {
      id: "gordis-fellowship-2025",
      title: "Gordis Teaching Fellowship",
      institution: "Johns Hopkins University",
      period: "Spring 2025",
      description:
        "Delivered a 3-credit course titled 'One Health, Antimicrobial Resistance and Disease X: Social, Clinical and Public Health Perspectives' for undergraduate students",
      type: "Course Instruction",
      image: "/placeholder.svg?height=200&width=300&text=Gordis+Fellowship",
      students: "Undergraduate Public Health Studies",
    },
    {
      id: "summer-institutes",
      title: "Summer Institute Modules",
      institution: "Johns Hopkins Bloomberg School of Public Health",
      period: "2023-2024",
      description:
        "Antimicrobial Resistance and the One Health Approach module for The Summer Institute Course on Child and Public Health",
      type: "Module Instruction",
      image: "/placeholder.svg?height=200&width=300&text=Summer+Institute",
      students: "Graduate and Professional",
    },
    {
      id: "one-health-course",
      title: "One Health Course Development",
      institution: "Indian Council of Medical Research",
      period: "February 2023",
      description:
        "Developed 'Global Health vs. One Health' and 'Basics of Research Ethics' modules for national-level course with 2,000+ annual enrollment",
      type: "Course Development",
      image: "/placeholder.svg?height=200&width=300&text=One+Health+Course",
      students: "National Level (2,000+ annually)",
    },
    {
      id: "ta-foundations",
      title: "Teaching Assistant - Foundations of International Health",
      institution: "Johns Hopkins Bloomberg School of Public Health",
      period: "Fall 2021, Fall 2023",
      description:
        "Teaching assistant for core international health course covering global disease burden, health systems, and interventions",
      type: "Teaching Assistantship",
      image: "/placeholder.svg?height=200&width=300&text=International+Health+TA",
      students: "Graduate Students",
    },
    {
      id: "ta-covid-response",
      title: "Teaching Assistant - COVID-19 Response in India",
      institution: "Johns Hopkins Bloomberg School of Public Health",
      period: "Fall 2020, Fall 2021",
      description:
        "TA for course examining India's COVID-19 response with focus on women and children's health and wellbeing",
      type: "Teaching Assistantship",
      image: "/placeholder.svg?height=200&width=300&text=COVID+Response+TA",
      students: "Graduate Students",
    },
  ]

  const presentations = [
    {
      id: "aids-2022",
      title:
        "Should a pill a day keep the doctor away? Re-examining assumptions about frequency of sex and continuity of PrEP use",
      conference: "AIDS 2022: The 24th International AIDS Conference",
      location: "Montreal, Canada",
      date: "July 2022",
      type: "Oral Presentation",
      authors: "Reed J, Chatterjee P, Were D, Osuka I, Musau A, Curran K, Mohan D",
      image: "/placeholder.svg?height=200&width=300&text=AIDS+2022",
      audience: "International",
    },
    {
      id: "imed-2016",
      title:
        "Developing a transdisciplinary database for operationalization of One Health surveillance for Japanese Encephalitis in India",
      conference: "The International Meeting on Emerging Diseases and Surveillance",
      location: "Vienna, Austria",
      date: "November 2016",
      type: "Oral Presentation",
      authors: "Rogawski ET, Chatterjee P, Kakkar M",
      image: "/placeholder.svg?height=200&width=300&text=IMED+Vienna",
      audience: "International",
    },
    {
      id: "iapsm-2015",
      title: "Tracking Outbreaks of Febrile Infectious Diseases in India Using Google Trends",
      conference: "42nd Annual Conference of the Indian Association of Preventive and Social Medicine",
      location: "Lucknow, India",
      date: "February 2015",
      type: "Oral Presentation",
      authors: "Chatterjee P",
      image: "/placeholder.svg?height=200&width=300&text=Google+Trends+Study",
      audience: "National",
    },
    {
      id: "who-pathogen-x-2022",
      title: "One Health, 'Disease X' and the Challenge of 'Unknown' Unknowns",
      conference: "WHO Symposium on Scientific strategies from recent outbreaks to help us prepare for Pathogen X",
      location: "Geneva, Switzerland",
      date: "August 2022",
      type: "Invited Seminar",
      authors: "Chatterjee P",
      image: "/placeholder.svg?height=200&width=300&text=WHO+Disease+X",
      audience: "International Policy",
    },
  ]

  const policyPresentations = [
    {
      id: "climate-change-wb",
      title: "Impact of Climate Change and Water and Food-Borne Infectious Diseases",
      organization:
        "National Center for Disease Control & Directorate of Health Services, Government of Madhya Pradesh",
      date: "December 2017",
      description:
        "Stakeholder meeting to develop State Action Plans on Climate Change and Human Health for West, Central and South Indian states",
      role: "Presenter on Impact of Climate Change on Water/Food Borne Diseases",
      image: "/placeholder.svg?height=200&width=300&text=Climate+Change+Policy",
      audience: "State Government Officials",
    },
    {
      id: "ocv-policy",
      title: "Developing a Policy Guidance for Operationalization of Oral Cholera Vaccines",
      organization:
        "ICMR – National Institute of Cholera and Enteric Diseases & Kolkata Metropolitan Development Authority",
      date: "October 2017",
      description:
        "Stakeholder meeting to assess need and priority actions for deploying Oral Cholera Vaccines in cholera hotspots in West Bengal",
      role: "Evidence portfolio development and cholera hotspot identification",
      image: "/placeholder.svg?height=200&width=300&text=OCV+Policy",
      audience: "Public Health Officials",
    },
    {
      id: "covid-ntf-secretariat",
      title: "Secretariat for the COVID-19 National Task Force (NTF) in India",
      organization: "Indian Council of Medical Research (ICMR), New Delhi",
      date: "March 2020 to July 2020",
      description:
        "Provided secretariat support to India's apex COVID-19 research and policy making body during the pandemic",
      role: "Managing secretariat, developing agendas, evidence synthesis, policy document drafting",
      image: "/placeholder.svg?height=200&width=300&text=COVID+NTF",
      audience: "National Policy Makers",
    },
    {
      id: "research-platform-sea",
      title: "Regional Enabler for South-East Asia Research Collaboration on Health (RESEARCH) Platform",
      organization: "Indian Council of Medical Research, WHO SEARO, TGHPRC",
      date: "August 2019",
      description:
        "Establishing RESEARCH Platform to accelerate research-led responses to emerging infectious disease threats in SEA region",
      role: "Review conduct, agenda planning, background document preparation, outcome statement drafting",
      image: "/placeholder.svg?height=200&width=300&text=SEA+Research+Platform",
      audience: "Regional Health Ministers",
    },
  ]

  if (selectedSection === "research-grants") {
    return (
      <div className="min-h-screen bg-black text-white">
        <header className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-transparent">
          <div className="flex items-center justify-between px-8 py-4">
            <Button variant="ghost" onClick={() => setSelectedSection(null)} className="text-white hover:text-gray-300">
              ← Back to Main
            </Button>
            <h1 className="text-red-600 text-2xl font-bold">RESEARCH GRANTS</h1>
          </div>
        </header>

        <div className="pt-20 px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {researchGrants.map((grant) => (
              <div
                key={grant.id}
                className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
                onMouseEnter={() => setHoveredCard(grant.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <img src={grant.image || "/placeholder.svg"} alt={grant.title} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <Badge
                      variant="secondary"
                      className={`${grant.status === "Completed" ? "bg-green-600" : "bg-blue-600"}`}
                    >
                      {grant.status}
                    </Badge>
                    <span className="text-sm text-gray-400">{grant.period}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{grant.title}</h3>
                  <p className="text-red-500 font-semibold mb-2">{grant.subtitle}</p>
                  <p className="text-gray-300 text-sm mb-3">{grant.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Funding:</span>
                      <span className="text-green-400">{grant.funding}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Role:</span>
                      <span>{grant.role}</span>
                    </div>
                    <div className="text-gray-400">
                      <span>Agency: </span>
                      <span className="text-white">{grant.agency}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-transparent">
        <div className="flex items-center justify-between px-8 py-4">
          <div className="flex items-center space-x-8">
            <h1 className="text-red-600 text-2xl font-bold">DR. PRANAB CHATTERJEE</h1>
            <nav className="hidden md:flex space-x-6">
              <a href="#experience" className="hover:text-gray-300 transition-colors">
                Experience
              </a>
              <a href="#education" className="hover:text-gray-300 transition-colors">
                Education
              </a>
              <a href="#research" className="hover:text-gray-300 transition-colors">
                Research
              </a>
              <a href="#publications" className="hover:text-gray-300 transition-colors">
                Publications
              </a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Globe className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Mail className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(to right, rgba(0,0,0,0.8), rgba(0,0,0,0.4)), url('/placeholder.svg?height=1080&width=1920&text=Global+Health+Research')`,
          }}
        />
        <div className="relative z-10 px-8 max-w-3xl">
          <div className="flex items-center space-x-4 mb-4">
            <Badge variant="secondary" className="bg-red-600 text-white">
              MBBS, MD, DTM&H
            </Badge>
            <Badge variant="secondary" className="bg-blue-600 text-white">
              PhD Candidate
            </Badge>
          </div>
          <h2 className="text-5xl md:text-7xl font-bold mb-4">
            Physician
            <br />
            Scientist
          </h2>
          <p className="text-xl mb-6 text-gray-300">
            Infectious Disease Epidemiologist specializing in Antimicrobial Resistance and One Health approaches. PhD
            Candidate at Johns Hopkins Bloomberg School of Public Health with 59+ peer-reviewed publications.
          </p>
          <div className="flex items-center space-x-6 mb-6 text-sm">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Baltimore, MD / New Delhi, India</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4" />
              <span>pchatterjee@jhu.edu</span>
            </div>
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4" />
              <span>+1-443-676-9610</span>
            </div>
          </div>
          <div className="flex space-x-4">
            <Button className="bg-red-600 text-white hover:bg-red-700 px-8 py-3">
              <Play className="h-5 w-5 mr-2" />
              View Research
            </Button>
            <Button variant="outline" className="border-gray-500 text-white hover:bg-gray-800 px-8 py-3 bg-transparent">
              <Info className="h-5 w-5 mr-2" />
              Contact
            </Button>
          </div>
        </div>
      </section>

      {/* Professional Experience Section */}
      <section id="experience" className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Professional Experience</h3>
        <div className="space-y-6">
          {professionalExperience.map((exp) => (
            <div
              key={exp.id}
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-[1.02]"
              onMouseEnter={() => setHoveredCard(exp.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className="flex flex-col lg:flex-row">
                <img
                  src={exp.image || "/placeholder.svg"}
                  alt={exp.company}
                  className="w-full lg:w-80 h-48 lg:h-auto object-cover"
                />
                <div className="p-6 flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="bg-red-600">
                      {exp.period}
                    </Badge>
                    <span className="text-sm text-gray-400">{exp.location}</span>
                  </div>
                  <h4 className="text-2xl font-bold mb-2">{exp.title}</h4>
                  <p className="text-red-500 font-semibold mb-2">{exp.company}</p>
                  <p className="text-gray-400 text-sm mb-3">{exp.department}</p>
                  <p className="text-gray-300 mb-4">{exp.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {exp.highlights.map((highlight, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Research Grants Section */}
      <section id="research" className="px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-3xl font-bold">Research Grant Participation</h3>
          <Button onClick={() => setSelectedSection("research-grants")} className="bg-red-600 hover:bg-red-700">
            View All Grants <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
        <div className="flex space-x-4 overflow-x-auto pb-4">
          {researchGrants.slice(0, 4).map((grant) => (
            <div
              key={grant.id}
              className="flex-shrink-0 w-80 bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredCard(grant.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <img src={grant.image || "/placeholder.svg"} alt={grant.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge
                    variant="secondary"
                    className={`${grant.status === "Completed" ? "bg-green-600" : "bg-blue-600"}`}
                  >
                    {grant.status}
                  </Badge>
                  <span className="text-sm text-gray-400">{grant.period.split(" - ")[0]}</span>
                </div>
                <h4 className="text-xl font-bold mb-2">{grant.title}</h4>
                <p className="text-red-500 font-semibold mb-2">{grant.subtitle}</p>
                <p className="text-gray-300 text-sm mb-3">{grant.description.substring(0, 100)}...</p>
                <div className="text-green-400 font-semibold">{grant.funding}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Publications Section */}
      <section id="publications" className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Publications</h3>

        {/* Peer-Reviewed Articles */}
        <div className="mb-12">
          <h4 className="text-2xl font-bold mb-6 text-red-500">Peer-Reviewed Journal Articles</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {peerReviewedArticles.map((article) => (
              <div
                key={article.id}
                className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
                onMouseEnter={() => setHoveredCard(article.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <img
                  src={article.image || "/placeholder.svg"}
                  alt={article.title}
                  className="w-full h-32 object-cover"
                />
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="bg-blue-600 text-xs">
                      {article.year}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {article.impact}
                    </Badge>
                  </div>
                  <h5 className="font-bold mb-2 text-sm leading-tight">{article.title}</h5>
                  <p className="text-red-500 font-semibold text-xs mb-2">{article.journal}</p>
                  <p className="text-gray-400 text-xs">{article.authors.substring(0, 50)}...</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Book Chapters */}
        <div className="mb-12">
          <h4 className="text-2xl font-bold mb-6 text-green-500">Book Chapters</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookChapters.map((chapter) => (
              <div
                key={chapter.id}
                className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
                onMouseEnter={() => setHoveredCard(chapter.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <img
                  src={chapter.image || "/placeholder.svg"}
                  alt={chapter.title}
                  className="w-full h-32 object-cover"
                />
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="bg-green-600 text-xs">
                      {chapter.year}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {chapter.type}
                    </Badge>
                  </div>
                  <h5 className="font-bold mb-2 text-sm leading-tight">{chapter.title}</h5>
                  <p className="text-green-500 font-semibold text-xs mb-2">{chapter.book}</p>
                  <p className="text-gray-400 text-xs">{chapter.publisher}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Policy Presentations Section */}
      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Presentations to Policymakers, Communities, and Stakeholders</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {policyPresentations.map((presentation) => (
            <div
              key={presentation.id}
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredCard(presentation.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <img
                src={presentation.image || "/placeholder.svg"}
                alt={presentation.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary" className="bg-purple-600">
                    {presentation.date}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {presentation.audience}
                  </Badge>
                </div>
                <h4 className="text-xl font-bold mb-2">{presentation.title}</h4>
                <p className="text-purple-500 font-semibold mb-2">{presentation.organization}</p>
                <p className="text-gray-300 text-sm mb-3">{presentation.description}</p>
                <p className="text-gray-400 text-sm">
                  <strong>Role:</strong> {presentation.role}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Professional Activities Section */}
      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Professional Activities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {professionalActivities.map((activity) => {
            const IconComponent = activity.icon
            return (
              <div
                key={activity.id}
                className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
                onMouseEnter={() => setHoveredCard(activity.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <img
                  src={activity.image || "/placeholder.svg"}
                  alt={activity.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <IconComponent className="h-8 w-8 text-red-500 mr-3" />
                    <h4 className="text-xl font-bold">{activity.title}</h4>
                  </div>
                  <ul className="space-y-2">
                    {activity.items.map((item, index) => (
                      <li key={index} className="text-gray-300 text-sm flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* Honors and Awards Section */}
      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Honors and Awards</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {honorsAwards.map((award) => (
            <div
              key={award.id}
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredCard(award.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <img src={award.image || "/placeholder.svg"} alt={award.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary" className="bg-yellow-600">
                    {award.year}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {award.type}
                  </Badge>
                </div>
                <h4 className="text-xl font-bold mb-2">{award.title}</h4>
                <p className="text-yellow-500 font-semibold mb-2">{award.organization}</p>
                <p className="text-gray-300 text-sm">{award.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Teaching Section */}
      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Teaching</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teachingActivities.map((teaching) => (
            <div
              key={teaching.id}
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredCard(teaching.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <img
                src={teaching.image || "/placeholder.svg"}
                alt={teaching.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary" className="bg-teal-600">
                    {teaching.period}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {teaching.type}
                  </Badge>
                </div>
                <h4 className="text-xl font-bold mb-2">{teaching.title}</h4>
                <p className="text-teal-500 font-semibold mb-2">{teaching.institution}</p>
                <p className="text-gray-300 text-sm mb-3">{teaching.description}</p>
                <p className="text-gray-400 text-xs">
                  <strong>Students:</strong> {teaching.students}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Presentations Section */}
      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-8">Scientific Presentations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {presentations.map((presentation) => (
            <div
              key={presentation.id}
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredCard(presentation.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <img
                src={presentation.image || "/placeholder.svg"}
                alt={presentation.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary" className="bg-indigo-600">
                    {presentation.date}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {presentation.type}
                  </Badge>
                </div>
                <h4 className="text-xl font-bold mb-2">{presentation.title}</h4>
                <p className="text-indigo-500 font-semibold mb-2">{presentation.conference}</p>
                <p className="text-gray-400 text-sm mb-2">{presentation.location}</p>
                <p className="text-gray-300 text-sm mb-3">{presentation.authors}</p>
                <Badge variant="outline" className="text-xs">
                  {presentation.audience} Audience
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="px-8 py-16 border-t border-gray-800">
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">Let's Collaborate on Global Health Research</h3>
          <p className="text-gray-400 mb-6">
            Interested in infectious disease research, antimicrobial resistance, or One Health approaches? Let's
            connect!
          </p>
          <div className="flex justify-center space-x-4 mb-6">
            <Button className="bg-red-600 hover:bg-red-700">
              <Mail className="h-4 w-4 mr-2" />
              Email Me
            </Button>
            <Button variant="outline">
              <Globe className="h-4 w-4 mr-2" />
              Visit Website
            </Button>
          </div>
          <div className="flex justify-center space-x-6 text-gray-400">
            <span>📧 pchatterjee@jhu.edu</span>
            <span>🐦 @scepticemia</span>
            <span>🌐 pranab.net</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
